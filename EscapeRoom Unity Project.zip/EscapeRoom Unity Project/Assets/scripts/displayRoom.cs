﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class displayRoom : MonoBehaviour
{
    public enum State { 
        normal, zoom, ChangeView
    };
    public State CurrentState { get; set; }

    private int currentRoom, previusRoom;
    public int getCurrentRoom(){return currentRoom; }
    public void setCurrentRoom(int value) 
    {
        if (value == 3) currentRoom = 1;
        else if (value == 0) currentRoom = 2;
        else currentRoom = value;
    
    }

    // Start is called before the first frame update
    void Start()
    {
        currentRoom = 1;
        previusRoom = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (currentRoom != previusRoom)
        {
            GetComponent<SpriteRenderer>().sprite = Resources.Load<Sprite>("escapeAsserts/scene" + currentRoom.ToString());
        }
    }
}
