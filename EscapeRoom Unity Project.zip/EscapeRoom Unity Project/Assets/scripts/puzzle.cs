﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;
public class puzzle : MonoBehaviour
{

    public bool IsCompleted = true;
    private GameObject displayImage, unlock_key, locked_key, audiopiece;

    private void Start()
    {
        displayImage = GameObject.Find("displayImage");
        locked_key = GameObject.Find("locked_key");
        unlock_key = GameObject.Find("unlock_key");
     //   audiopiece = GameObject.Find<AudioSource>();
        unlock_key.SetActive(false);
        locked_key.SetActive(true);

    }
    private void Update()
    {
       // HideDisplay();
       if (CompletedPuzzle()) {
            Debug.Log("completed!");
           
            locked_key.SetActive(false);
         
            unlock_key.SetActive(true);

            unlock_key.GetComponent<AudioSource>().Play();
        }
    }

    void HideDisplay() { 
        if (Input.GetMouseButtonDown(0)&& !UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject()) {
            this.gameObject.SetActive(false);
        }
        if (displayImage.GetComponent<displayRoom>().CurrentState == displayRoom.State.normal)
        {
            this.gameObject.SetActive(false);
        }
    }

    bool CompletedPuzzle()
    {
        IsCompleted = true;
        //if (IsCompleted) return true;
        var puzzlePieces = FindObjectsOfType<PuzzlePiece>();
        foreach (PuzzlePiece puzzlePiece in puzzlePieces)
        {
           //Debug.Log(puzzlePiece.gameObject.GetComponent<Image>().sprite.name);
           if (!(int.Parse(puzzlePiece.gameObject.name.Substring(puzzlePiece.gameObject.name.Length - 1)) ==
            int.Parse(puzzlePiece.gameObject.GetComponent<Image>().sprite.name.Substring(puzzlePiece.gameObject.GetComponent<Image>().sprite.name.Length - 1))))
            {

                IsCompleted = false;
            }

        }
        return IsCompleted;
    }

}
