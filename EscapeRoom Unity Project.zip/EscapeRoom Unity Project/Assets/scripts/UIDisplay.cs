﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class UIDisplay : MonoBehaviour, IInteractable
{
    public GameObject DisplayObject;
    public void Interact(displayRoom currentDisplay)
    {
        DisplayObject.SetActive(true);
    }
}

internal interface IInteractable
{
}