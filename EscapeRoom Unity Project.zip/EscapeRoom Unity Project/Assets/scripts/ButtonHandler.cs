﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonHandler : MonoBehaviour
{

    public GameObject currentDisplayGameObj;

    void Start() { 

        //currentDisplay = GameObject.Find("displayImage").GetComponent<displayRoom>();
       //Debug.Log(currentDisplay.getCurrentRoom());
    }

public void OnRightClickArrow()
{
        currentDisplayGameObj.GetComponent<displayRoom>().setCurrentRoom (currentDisplayGameObj.GetComponent<displayRoom>().getCurrentRoom() + 1);
        Debug.Log(currentDisplayGameObj.GetComponent<displayRoom>().getCurrentRoom());
}

    public void OnLeftClickArrow()
    {
        currentDisplayGameObj.GetComponent<displayRoom>().setCurrentRoom(currentDisplayGameObj.GetComponent<displayRoom>().getCurrentRoom() - 1);
        Debug.Log(currentDisplayGameObj.GetComponent<displayRoom>().getCurrentRoom());
    }
}
