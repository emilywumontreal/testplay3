﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using UnityEngine.EventSystems;

public class PuzzlePiece: MonoBehaviour, IPointerClickHandler
{
    private GameObject puzzle;
    private Sprite changeSprite;

    public void Start()
    {
        puzzle = GameObject.Find("puzzle");
    }
    public void OnPointerClick(PointerEventData eventData)
    {
        Debug.Log(puzzle.GetComponent<puzzle>().IsCompleted);
        if (puzzle.GetComponent<puzzle>().IsCompleted) return;
        var puzzlePieces = FindObjectsOfType<PuzzlePiece>();
        foreach (PuzzlePiece puzzlePiece in puzzlePieces) {
         
           // Debug.Log(int.Parse(puzzlePiece.gameObject.name.Substring(puzzlePiece.gameObject.name.Length - 1)) + 3);
            if (
            int.Parse(this.gameObject.name.Substring(this.gameObject.name.Length -1))== 
            int.Parse(puzzlePiece.gameObject.name.Substring(puzzlePiece.gameObject.name.Length - 1)) +1
                ||
            int.Parse(this.gameObject.name.Substring(this.gameObject.name.Length - 1)) ==
            int.Parse(puzzlePiece.gameObject.name.Substring(puzzlePiece.gameObject.name.Length - 1)) - 1 
            ||
            int.Parse(this.gameObject.name.Substring(this.gameObject.name.Length - 1)) ==
            int.Parse(puzzlePiece.gameObject.name.Substring(puzzlePiece.gameObject.name.Length - 1)) + 3
            ||
            int.Parse(this.gameObject.name.Substring(this.gameObject.name.Length - 1)) ==
            int.Parse(puzzlePiece.gameObject.name.Substring(puzzlePiece.gameObject.name.Length - 1)) - 3
            )

                {
                //Debug.Log(this.gameObject.name);
                //Debug.Log(puzzlePiece.gameObject.name);


                if (puzzlePiece.GetComponent<Image>().sprite.name =="orion_constellation_6")
                        {
                            changeSprite = puzzlePiece.GetComponent<Image>().sprite;
                  //          Debug.Log("changing:: "+changeSprite.name);
                           // ChangeSprites(GetComponent<Image>().sprite, changeSprite);
                           ChangeImageSprites(GetComponent<Image>(), puzzlePiece.GetComponent<Image>());
                }
            }
        }
    }

    void ChangeSprites(Sprite firstSprite, Sprite secondSprite) {

        Sprite temp = firstSprite;
      //  Debug.Log("source:: "+temp);
      //  Debug.Log("dest:: " + secondSprite);
        firstSprite = secondSprite;
        secondSprite = temp;

    }

    void ChangeImageSprites(Image firstSprite, Image secondSprite)
    {

        Sprite temp = firstSprite.sprite;
    //    Debug.Log("source:: " + temp);
    //    Debug.Log("dest:: " + secondSprite);
        firstSprite.sprite = secondSprite.sprite;
        secondSprite.sprite = temp;
        this.GetComponent<AudioSource>().Play();
    }
}
