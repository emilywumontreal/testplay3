﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectManage : MonoBehaviour
{
    private displayRoom currentDisplay;
    public GameObject[] ObjectsToMange;
    public GameObject[] UIRenerObjects;
    // Start is called before the first frame update
    void Start()
    {
        currentDisplay = GameObject.Find("displayImage").GetComponent<displayRoom>();
        RenderUI();
    }

    // Update is called once per frame
    void Update()
    {
        mangeObjects();
    }

    void mangeObjects()
    { 
        for (int i=0; i < ObjectsToMange.Length; i++) { 
            if (ObjectsToMange[i].name == currentDisplay.GetComponentInParent<SpriteRenderer>().sprite.name)
            {
                ObjectsToMange[i].SetActive(true); 
            } else {
                ObjectsToMange[i].SetActive(false);
            }
        }
    }

    void RenderUI() { 
        for(int i = 0; i < UIRenerObjects.Length; i++) {
            UIRenerObjects[i].SetActive(true);
        }
    }
}
